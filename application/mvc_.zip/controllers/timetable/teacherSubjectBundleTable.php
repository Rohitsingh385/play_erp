<?php foreach ($subjectList as $key => $value) { ?>
	<tr>
	  <td style="background: #337ab7; color: white !important;">S.No.</td>
	  <td style="background: #337ab7; color: white !important;">Class</td>
	  <td style="background: #337ab7; color: white !important;">Subject</td>
	  <td style="background: #337ab7; color: white !important;">Periods</td>
	</tr>
<?php } ?>