<ol class="breadcrumb">
	<li class="breadcrumb-item"><a href="#">
			<h4><b>Certificate's</b></h4>
		</a> <i class=""></i></li>
	<li class="breadcrumb-item" style="float: right;padding:2px"><i class="fa fa-angle-left"></i> <a href="<?php echo base_url('payroll/dashboard/emp_dashboard'); ?>" style="font-size:18px;">Back </a></li>
</ol>
<style>
	.breadcrumb>li+li:before {
		content: "";
	}		
</style>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Transfer_certificate/transfer_certificate'); ?>"> 
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Transfer <br /> Certificate</h3>
						</div>
						
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Certificate/cancel_reprint_tc'); ?>"> 
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; height:5px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Cancel Reprint <br />TC</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Certificate/char_show'); ?>"> 
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Character <br />Certificate</h3>
						</div>
					</div></a>
				</div>
				 <div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Bonafide_certificate/show_bonafide'); ?>">
					 <div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Bonafide <br/> Certificate</h3>
						</div>
						
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Date_of_birth_certificate/show_dob'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Date of Birth<br />  Certificate</h3>
						</div>
						
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Tution_fee_certificate/show_tution'); ?>">
					 <div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Tuition Fee <br />Certificate</h3>
						</div>
					</div></a>
				</div> 
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div> 
 <div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				
				
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Fee_paid_all_certificate/show_tution'); ?>">
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Paid(All)  <br />Certificate</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Provisional_certificate/show_pro'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Provisional <br /> Certificate</h3>
						</div>
						
					</div></a>
				</div>
				<!-- <div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Fees_master/fee_head_master'); ?>"> 
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Head  <br />Master</h3>
						</div>
					</div></a>
				</div> -->
				<!-- <div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Late_finemaster/late_fine'); ?>"> 
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Late Fine <br />Master     </h3>
						</div>
					</div></a>
				</div> -->
				<!-- <div class="col-md-3 four-grid">
					<a href="<?php //echo base_url('Scholarshipownedby/scholarshipownedby'); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>ScholarShip<br/> Owned By</h3>
						</div>
						
					</div></a>
				</div> -->
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>