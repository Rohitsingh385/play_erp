
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Notice List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-bullhorn"></i> Home</a></li>
        <li class="active">Notice</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script type="text/javascript">
	$(function () {
    $('#example2').DataTable()
  })
</script>