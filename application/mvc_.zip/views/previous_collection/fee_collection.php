<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.html">Fee Collection</a> <i class="fa fa-angle-right"></i></li>
</ol>
<style type="text/css">
  body{
   font-family: 'Aldrich', sans-serif;
  }
</style>
<!--four-grids here-->
	<div class="row">
		<div class="four-grids">
					<div class="col-md-3 four-grid">
						<a href="<?php echo base_url('Monthly_collection/month_collection'); ?>">
						<div class="four-agileits">
							<div class="icon">
								<i class="fas fa-rupee-sign" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Monthly Fee <br /> Collection</h3>
								<!-- <h4> 24,420  </h4> -->
								
							</div>
							
						</div></a>
					</div>
					<div class="col-md-3 four-grid">
						<a href="<?php echo base_url('Fees_collection/misc_collection'); ?>">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="fas fa-rupee-sign" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Miscellaneous <br /> Collection</h3>
								<!-- <h4>15,520</h4> -->

							</div>
							
						</div></a>
					</div>
					<div class="col-md-3 four-grid">
						<a href="<?php echo base_url('Fees_collection/collection_without_adm'); ?>">
						<div class="four-w3ls">
							<div class="icon">
								<i class="fas fa-rupee-sign" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Collection Without <br /> Admission No</h3>
								<!-- <h4>12,430</h4> -->
								
							</div>
							
						</div></a>
					</div>
					<div class="col-md-3 four-grid">
						<a href="<?php echo base_url('Sunil_enterprises/month_collection'); ?>">
						<div class="four-wthree">
							<div class="icon">
								<i class="fas fa-rupee-sign" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Fee Collection <br/> Sunil Enterprises</h3>
							</div>
							
						</div></a>
					</div>
					<div class="clearfix"></div>
		</div>
	</div>
        <div class="clearfix"></div>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<div class="inner-block">

</div>
<br />
<!--inner block end here-->
<!--copy rights start here-->
