<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.html">Class Report</a> <i class="fa fa-angle-right"></i></li>
</ol>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Class_report/class_wise_ledger'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Class Wise<br /> Ledger</h3>
							<!-- <h4> 24,420  </h4> -->
						</div>
						
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Student_strength/show_strenght'); ?>">
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Student <br />Strength</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Feeheadwise_classledger/feehead_class_wise_ledger'); ?>">
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Head Wise <br />Class Ledger</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Feepaid_ledger/show_feepaid_ledger'); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Paid<br/> Ledger</h3>
						</div>
						
					</div></a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Reconcilation_ledger/index'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Reconciliation<br /> Ledger</h3>
							<!-- <h4> 24,420  </h4> -->
						</div>
						
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Student_ledger_report/show_student_ledger'); ?>">
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Student <br />Ledger</h3>
						</div>
					</div></a>
				</div>
				<!--<div class="col-md-3 four-grid">
					<a href="<?php //echo base_url('Feeheadwise_classledger/feehead_class_wise_ledger'); ?>">
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Head Wise <br />Class Ledger</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php// echo base_url('Feepaid_ledger/show_feepaid_ledger'); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Paid<br/> Ledger</h3>
						</div>
						
					</div></a>
				</div>-->
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>