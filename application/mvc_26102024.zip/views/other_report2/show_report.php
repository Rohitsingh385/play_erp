<ol class="breadcrumb">
	<li class="breadcrumb-item"><a href="#">
			<h4><b>Other Report</b></h4>
		</a> <i class=""></i></li>
	<li class="breadcrumb-item" style="float: right;padding:2px"><i class="fa fa-angle-left"></i> <a href="<?php echo base_url('Report/typeofreports'); ?>" style="font-size:18px;">Back </a></li>
</ol>
<style>
	.breadcrumb>li+li:before {
		content: "";
	}
</style>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<!-- <div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Other_report/show_other_report2'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Award<br /> List</h3>
							 <h4> 24,420  </h4> -->
						<!-- </div>
						
					</div></a>
				</div> -->
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Admission_registar/show_registar_student'); ?>">
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Admission <br />Register</h3>
						</div>
					</div></a>
				</div>
				<!--<div class="col-md-3 four-grid">
					<a href="<?php //echo base_url(''); ?>">
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Student <br /> Ledger</h3>
						</div>
					</div></a>
				</div>-->
				<!--<div class="col-md-3 four-grid">
					<a href="<?php //echo base_url(); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Bonafide <br/> Certificate</h3>
						</div>
						
					</div></a>
				</div>-->
				

				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
</br></br></br></br></br></br></br></br></br></br>