<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Noticelist extends MY_controller {
	public function __construct(){
		parent:: __construct();
	}

	public function index()
	{
		$this->Parent_templete('parents_dashboard/noticeList');
	}
}