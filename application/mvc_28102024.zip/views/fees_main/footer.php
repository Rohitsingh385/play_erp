<div class="copyrights">
<div class='row'>
	<div class="col-sm-1">
		
	</div>
  <div class="col-sm-7">
  	<p>&nbsp;&nbsp;<img src="<?php echo base_url('assets/dash_images/mica_img.png'); ?>" style="width:50px;"> &nbsp;© All Rights Reserved | Design by  <a href="http://micaeduco.com/" target="_blank">MICA EDUCATIONAL COMP (P) LTD</a>&nbsp;&nbsp; <p></div>
  
  <div class="col-sm-4" style="line-height:50px;"><p>Powered By : <a href="#">Soft Solution</a></p></div>
</div>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
