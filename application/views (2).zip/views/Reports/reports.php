<!-- <ol class="breadcrumb">
	<li class="breadcrumb-item"><a href="index.html"> Reports</a> <i class="fa fa-angle-right"></i></li>
</ol>
<style type="text/css">
	body {
		font-family: 'Aldrich', sans-serif;
	}
</style> -->
<!--four-grids here-->
<!-- <div class="row">
	<div class="four-grids">
		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Report/daily_monthlycollecion'); ?>">
				<div class="four-agileits">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3>Daily Collection <br /> Report</h3> -->
<!-- <h4> 24,420  </h4> -->
<!-- 
					</div>

				</div>
			</a>
		</div>
		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Report/monthlycollecion'); ?>">
				<div class="four-agileinfo">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3>Monthly Collection <br /> Report</h3>
					</div>

				</div>
			</a>
		</div>
		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Feepaid_ledger/show_feepaid_ledger'); ?>">
				<div class="four-wthree">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3> Student Fee <br /> Paid Details</h3>
					</div>

				</div>
			</a>
		</div>

		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Student_strength/show_strenght'); ?>">
				<div class="four-agileinfo">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3>Class Wise Consolated Strength</h3>
					</div>
				</div>
			</a>
		</div>

		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Bus_report/show_report'); ?>">
				<div class="four-wthree">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3> Bus Report</h3></br>
					</div>

				</div>
			</a>
		</div>
		<div class="col-md-2 four-grid">
			<a href="<?php echo base_url('Report/Fee_Defaulter_List'); ?>">
				<div class="four-agileits">
					<div class="icon">
						<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
					</div>
					<div class="four-text">
						<h3>Fee Defaulter<br /> List</h3>
					</div>

				</div>
			</a>
		</div>

		<div class="row">
			<div class="col-md-12 col-lg-12 col-sm-12">
				<div class="row">

					<div class="four-grids">

						<div class="col-md-2 four-grid">
							<a href="<?php echo base_url('Student_report/studentinformation'); ?>">
								<div class="four-wthree">
									<div class="icon">
										<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
									</div>
									<div class="four-text">
										<h3> Student's<br />List</h3><br />
									</div>

								</div>
							</a>
						</div> -->
<!-- <div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Bus_report/show_report'); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3> Bus<br/>Report</h3><br />
						</div>
						
					</div></a>
				</div> -->
<!-- <div class="col-md-2 four-grid">
							<a href="<?php echo base_url('Other_report/show_other_report'); ?>">
								<div class="four-wthree">
									<div class="icon">
										<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
									</div>
									<div class="four-text">
										<h3> Other<br />Report</h3><br />
									</div>

								</div>
							</a>
							<br>


						</div>
						<div class="col-sm-12">
							<a class="btn btn-danger pull-right" id="" href="<?php echo base_url('payroll/dashboard/emp_dashboard'); ?>">BACK</a>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div> -->

<!-- /script-for sticky-nav -->
<!--inner block start here-->
<!-- <div class="inner-block">

		</div>
		<br /> -->
<!--inner block end here-->
<!--copy rights start here-->
<style>
	.breadcrumb>li+li:before {
		content: "";
	}
</style>
<ol class="breadcrumb">
	<li class="breadcrumb-item"><a href="#">
			<h4>Reports</h4>
		</a> <i class=""></i></li>
	<li class="breadcrumb-item" style="float: right;padding:2px"><i class="fa fa-angle-left"></i> <a href="<?php echo base_url('payroll/dashboard/emp_dashboard'); ?>" style="font-size:18px;">Back </a></li>
</ol>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Report/daily_monthlycollecion'); ?>">
						<div class="four-agileits">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Daily Collection <br /> Report</h3>
							</div>

						</div>
					</a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Report/monthlycollecion'); ?>">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; height:5px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Monthly Collection <br /> Report</h3>
							</div>
						</div>
					</a>
				</div>
				<!-- <div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Report/sunilmonthlycollecion'); ?>">
						<div class="four-agileits">
							<div class="icon">
								<i class="fa fa-file" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3 style="font-size: 17.5px !important;">Sunil Enterprises Monthly Collection Report</3>
							</div>

						</div>
					</a>
				</div> -->
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Feepaid_ledger/show_feepaid_ledger'); ?>">
						<div class="four-w3ls">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3> Student Fee <br /> Paid Details</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Student_strength/show_strenght'); ?>">
						<div class="four-wthree">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3 style="font-size: 19.5px !important;">Class Wise <br />Consolated Strength</h3>
							</div>

						</div>
					</a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Bus_report/show_report'); ?>">
						<div class="four-agileits">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3> Bus Report</h3></br>
							</div>

						</div>
					</a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Other_report/show_other_report'); ?>">
						<div class="four-agileinfo">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3> Other<br />Report</h3>
							</div>
						</div>
					</a>
				</div>

				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				

				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Student_report/studentinformation'); ?>">
						<div class="four-w3ls">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3> Student's<br />List</h3>
							</div>
						</div>
					</a>
				</div>
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Report/Fee_Defaulter_List'); ?>">
						<div class="four-agileits">
							<div class="icon">
								<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
							</div>
							<div class="four-text">
								<h3>Fee Defaulter<br /> List</h3>
							</div>

						</div>
					</a>
				</div>
				<!-- <div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Fees_master/fee_head_master'); ?>"> 
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Head  <br />Master</h3>
						</div>
					</div></a>
				</div> -->
				<!-- <div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Late_finemaster/late_fine'); ?>"> 
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Late Fine <br />Master     </h3>
						</div>
					</div></a>
				</div> -->
				<!-- <div class="col-md-3 four-grid">
					<a href="<?php //echo base_url('Scholarshipownedby/scholarshipownedby'); 
								?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>ScholarShip<br/> Owned By</h3>
						</div>
						
					</div></a>
				</div> -->
				<div class="clearfix"></div>
			</div>
		</div>
	</div>

</div>