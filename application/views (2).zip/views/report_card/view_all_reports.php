<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.html">Reports</a> <i class="fa fa-angle-right"></i></li>
</ol>
<div style="padding: 25px; background-color: white; border-top:3px solid #337ab7;">

<div class='container'>
  <div class='row'>
    <div class='col-sm-12'>
	<a href='<?php echo base_url('report_card/Report_card_temp_save/topper_list'); ?>' target="_blank">
	  <button type='button' class='btn btn-success'>Topper List</button>
	</a>
	
	<a href='<?php echo base_url('report_card/subject_analysis'); ?>'target="_blank">
	  <button type='submit' class='btn btn-danger'>Subject Analysis</button>
	</a>
	
	<a href='<?php echo base_url('report_card/Percentage_report'); ?>'target="_blank">
	  <button type='submit' class='btn btn-info'>Percentage Report</button>
	</a>
	
	<a href='<?php echo base_url('report_card/Grd_analysis_report'); ?>'target="_blank">
	  <button type='submit' class='btn btn-warning'>Grade Analysis</button>
	</a>
	
	<a href='<?php echo base_url('report_card/performance_graph_report'); ?>'target="_blank">
	  <button type='submit' class='btn btn-primary'>Average subject Graph</button>
	</a>
	</div>
  </div><br />
  
  <div class='row'>
    <div class='col-sm-12'>
	  <a href='<?php echo base_url('report_card/Higest_sub_graph'); ?>'target="_blank">
		<button type='submit' class='btn btn-warning'>Higest Subject  Graph</button>
	  </a>
	</div>
  </div>
</div>

</div>
<br /><br />