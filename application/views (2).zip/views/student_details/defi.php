<br />
<div class="form-group col-md-4">
    <label>Admission No:</label>
    <input type="text" name="adm_no" id="adm_no" class="form-control">
</div>