<ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.html"><h4>Fee Collection</h4></a> <i class=""></i></li>
</ol>
<div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-2 four-grid">
					<a href="<?php echo base_url('Feegeneration/fee_generation_gui'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>feegeneration<br /> data</h3>
						</div>
						
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Fees_master/fee_head_master'); ?>"> 
					<div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Fee Head  <br />Master</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-2 four-grid">
					 <a href="<?php echo base_url('Late_finemaster/late_fine'); ?>"> 
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Late Fine <br />Master     </h3>
						</div>
					</div></a>
				</div>
				<!-- <div class="col-md-3 four-grid"> -->
					<!-- <a href="<?php //echo base_url('Scholarshipownedby/scholarshipownedby'); ?>"> -->
					<!-- <div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>ScholarShip<br/> Owned By</h3>
						</div>
						
					</div></a>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div> -->
<!-- <div class="row">
	<div class="col-md-12 col-lg-12 col-sm-12">
		<div class="row">
			<div class="four-grids">
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Freeship_studentlist/index'); ?>">
					<div class="four-agileits">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Freeship<br /> Student List</h3>
						</div>
						
					</div></a>
				</div> -->
				<div class="col-md-3 four-grid">
					<!-- <a href="<?php //echo base_url('Physically_handicap'); ?>"> -->
					<!-- <div class="four-agileinfo">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>Physically Handicapped <br />Student Report</h3>
						</div>
					</div></a>
				</div> -->
				<!--<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Scholarship_report/studentscholarshipinformation'); ?>">
					<div class="four-w3ls">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>ScholarShip <br />Class Wise</h3>
						</div>
					</div></a>
				</div>
				<div class="col-md-3 four-grid">
					<a href="<?php echo base_url('Scholarshipownedby/scholarshipownedby'); ?>">
					<div class="four-wthree">
						<div class="icon">
							<i class="fas fa-address-card" style="font-size:30px; color: #fff;"></i>
						</div>
						<div class="four-text">
							<h3>ScholarShip<br/> Owned By</h3>
						</div>
						
					</div></a>
				</div>-->
				<div class="clearfix"></div>
			</div>
		</div>
	</div></br></br>
	<center>
		<a class="btn btn-danger pull-right" id="" href="<?php echo base_url('Student_report/show_studentpanel3'); ?>">BACK</a></center>
</div>